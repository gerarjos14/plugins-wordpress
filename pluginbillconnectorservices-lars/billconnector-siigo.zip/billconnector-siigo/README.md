# Alurack


## Error carga de productos
## Desde la página de siigo

<b>request_limimt</b>
Están llegando solicitudes demasiado rápido a la API. Recomendamos una retirada exponencial de sus solicitudes. Importante: > Para la empresa de pruebas las solicitudes son de 10 request por minuto > Empresas en producción son 100 request por minuto.