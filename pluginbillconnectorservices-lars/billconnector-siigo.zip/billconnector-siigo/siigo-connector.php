<?php
/**
 * Archivo del plugin 
 * Este archivo es leído por WordPress para generar la información del plugin
 * en el área de administración del complemento. Este archivo también incluye 
 * todas las dependencias utilizadas por el complemento, registra las funciones 
 * de activación y desactivación y define una función que inicia el complemento.
 *
 * @link                http://misitioweb.com
 * @since               1.0.0
 * @package             Siigo_Connector
 *
 * @wordpress-plugin
 * Plugin Name:         BillConnector SIIGO
 * Plugin URI:          https://billconnector.com
 * Description:         Descripción corta de nuestro plugin
 * Version:             2.0.0
 * License:             GPL2
 * License URI:         https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:         siigo-connector-textdomain
 * Domain Path:         /languages
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}
global $wpdb;
define( 'SIIGO_BC_REALPATH_BASENAME_PLUGIN', dirname( plugin_basename( __FILE__ ) ) . '/' );
define( 'SIIGO_BC_PLUGIN_DIR_PATH', plugin_dir_path( __FILE__ ) );
define( 'SIIGO_BC_PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );
define( 'SIIGO_BC_FILE', __FILE__);

define( 'SIIGO_BC_URL_API', "https://api.siigo.com/" );

define('BC_TABLE_SGO_PRODUCTS', "{$wpdb->prefix}bc_sgo_products");
define('BC_TABLE_SGO_CUSTOMERS', "{$wpdb->prefix}bc_sgo_customers");
define('BC_TABLE_SGO_KEYS', "{$wpdb->prefix}bc_sgo_keys");



define('SERVICE_SIIGO_ALEGRA_SLUG', 'billconnector-alegra/billconnector-alegra.php');
define('SERVICE_SIIGO_BILLCONNECTOR', 'billconnectorservices/billconnector.php');
define('SERVICE_SIIGO_SIIGO_SLUG', 'billconnector-siigo/siigo-connector.php');
define('SERVICE_SIIGO_SUNAT_SLUG', 'billconnector-sunat/billconnector-sunat.php');
define('SERVICE_SIIGO_SII_SLUG', 'billconnector-sii/billconnector.php');

/**
 * Código que se ejecuta en la activación del plugin
 */
function activate_siigo_connector() {
    require_once SIIGO_BC_PLUGIN_DIR_PATH . 'includes/class-sc-activator.php';
	SC_Activator::activate();
    if ( !is_plugin_active(SERVICE_SIIGO_BILLCONNECTOR) ) {
		deactivate_plugins(SERVICE_SIIGO_ALEGRA_SLUG);    
	} 

    global $wpdb;

    $data = array(
        'active' => 1,
    );
    $result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'SIIGO']);
}
/**
 * Código que se ejecuta en la desactivación del plugin
 */
function deactivate_siigo_connector() {
    require_once SIIGO_BC_PLUGIN_DIR_PATH . 'includes/class-sc-deactivator.php';
	SC_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_siigo_connector' );
register_deactivation_hook( __FILE__, 'deactivate_siigo_connector' );

require_once SIIGO_BC_PLUGIN_DIR_PATH . 'includes/class-sc-master.php';
require_once SIIGO_BC_PLUGIN_DIR_PATH . '/includes/check-services-active.php';

function run_sc_master() {
    $sc_master = new SC_Master;
    $sc_master->run();
}

run_sc_master();