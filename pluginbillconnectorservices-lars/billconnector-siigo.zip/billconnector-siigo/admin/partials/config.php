<form method="POST" class="form-keys">
          <div class="modal-body">
            <h5 style="font-size: 1.1rem;">Sitio Web</h5>
            <table class="form-table p-2">   
              <tr>
                  <th class="row-title">
                      <label class="text-bc" for="website">Url</label>
                  </th>
                  <td>
                      <input id="website" name="website" class="regular-text form-control inputs-admin-config" type="text" 
                      value="<?php if($result){echo $result->website;}?>"
                      >
                  </td>
              </tr>   
            </table>   
            <hr>
            <h5 style="font-size: 1.1rem;">Api Siigo</h5>
            <table class="form-table p-2">  
                <tr>
                    <th class="row-title">
                        <label class="text-bc" for="username">Nombre de usuario</label>
                    </th>
                    <td>
                        <input id="username" name="username" class="regular-text form-control inputs-admin-config" type="text" 
                        value="<?php if($result){echo $result->username;}?>"
                        >
                    </td>
                </tr>      
                <tr>
                    <th class="row-title">
                        <label class="text-bc" for="access_key">Clave del acceso</label>
                    </th>      
                    <td>
                        <input id="access_key" name="access_key" class="regular-text form-control inputs-admin-config" type="text" 
                        value="<?php if($result){echo $result->access_key;}?>"
                        >
                    </td>             
                </tr>   
            </table>   
            <hr> 
            <h5 style="font-size: 1.1rem;">Woocommerce</h5>
            <table class="form-table p-2">   
              <tr>
                  <th class="row-title">
                      <label class="text-bc" for="consumer_key">Clave del cliente</label>
                  </th>      
                  <td>
                      <input id="consumer_key" name="consumer_key" class="regular-text form-control inputs-admin-config" type="text" 
                      value="<?php if($result){echo $result->consumer_key;}?>"
                      >
                  </td>             
              </tr>          
              <tr>
                  <th class="row-title">
                      <label class="text-bc" for="consumer_secret">Clave secreta de cliente</label>
                  </th>      
                  <td>
                      <input id="consumer_secret" name="consumer_secret" class="regular-text form-control inputs-admin-config" type="text" 
                      value="<?php if($result){echo $result->consumer_secret;}?>"
                      >
                  </td>             
              </tr>       
            </table>  
          </div>
          <div class="modal-footer">
            <button id="send-keys" type="button" class="btn btn-bc btn-submit-config text-bc">Guardar cambios</button>
          </div>
        </form>
