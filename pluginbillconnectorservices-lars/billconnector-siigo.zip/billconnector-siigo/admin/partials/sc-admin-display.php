<?php

 /**
  * Proporcionar una vista de área de administración para el plugin
  *
  * Este archivo se utiliza para marcar los aspectos de administración del plugin.
  *
  * @since desde 1.0.0
  *
  * @package    Siigo_Connector
  * @subpackage Siigo_Connector/admin/partials
  */
    global $wpdb;

    $helpers = new SC_Helpers;
    $result =  $helpers->get_keys_db();  
    
    $query_gral = "SELECT * FROM {$wpdb->prefix}bc_config ORDER BY id ASC LIMIT 1;";
    $general_settings = $wpdb->get_row($query_gral);
?>
<link href='https://fonts.googleapis.com/css?family=Baloo+2' rel='stylesheet'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<link rel="stylesheet" href="<?php echo SIIGO_BC_PLUGIN_DIR_URL . '/public/css/bc-admin.css' ?>">
<link rel="stylesheet" href="<?php echo SIIGO_BC_PLUGIN_DIR_URL . 'admin/css/index.css' ?>">
<link rel="stylesheet" href="<?php echo SIIGO_BC_PLUGIN_DIR_URL . 'admin/css/admin-panel.css' ?>">
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>



<div class="wrap">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-title-plugin">
                    <div class="row">
                        <div class="col-sm-3 col-container-logo" style="max-width: none !important;">
                            <img class="bill-logo" src="<?php echo SIIGO_BC_PLUGIN_DIR_URL . 'public/images/Asset-2.png' ?>" alt="">
                        </div>
                        <div class="col-sm-6">
                            <h1 class="wp-heading-inline title-section-page">BillConnector - SIIGO</h1>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4"> 
                <div class="card card-config">
                    <div class="card-body list-group list-edit" id="list-tab" role="tablist">
                        <h5 class="text-sp"><b>SIIGO</b></h5>                        
                        <hr class="divideer">
                        <a class="list-group-item list-group-item-action nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">Configuración SIIGO</a>
                    </div>                
                </div>
            </div> 

            <div class="col-md-8">    
                <div class="tab-content" id="v-pills-tabContent">
                    <div class="card card-config tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                        <div class="card-body">
                            <?php include('config.php') ?>
                            
                        </div>
                    </div>                    
                </div>                   
            </div>     
        </div>     
    </div> 
</div>

