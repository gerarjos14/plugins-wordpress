<?php

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );


// verifico si está activo el plugin de billconnector services
if(!(is_plugin_active(SERVICE_SIIGO_BILLCONNECTOR))){
    $data = array(
        'active' => 0,
    );
    $result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'SIIGO']);
    // como no está activo, desactivo alegra
    deactivate_plugins(SERVICE_SIIGO_SIIGO_SLUG);    

}

/**
 * Filtro para saber si hay 'conflicto de convivencia'
 * @author Matías
 */

if ( is_plugin_active(SERVICE_SIIGO_ALEGRA_SLUG) ) {
    $data = array(
			'active' => 0,
		);
    $result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'ALEGRA']);
    deactivate_plugins(SERVICE_SIIGO_ALEGRA_SLUG);    
}   

if ( is_plugin_active(SERVICE_SIIGO_SII_SLUG) ) {
    $data = array(
			'active' => 0,
		);
    $result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'SII']);
    deactivate_plugins(SERVICE_SIIGO_SII_SLUG);    
}   

if ( is_plugin_active(SERVICE_SIIGO_SUNAT_SLUG) ) {
    $data = array(
			'active' => 0,
		);
    $result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'SUNAT']);
    deactivate_plugins(SERVICE_SIIGO_SUNAT_SLUG);    
}   


