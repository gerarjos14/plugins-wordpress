<?php

/**
 * Se activa cuando el plugin va a ser desinstalado
 *
 * @link       http://misitioweb.com
 * @since      1.0.0
 *
 * @package    Siigo_Connector
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/*
 * Agregar todo el código necesario
 * para eliminar ( como las bases de datos, limpiar caché,
 * limpiar enlaces permanentes, etc. ) en la desinstalación
 * del plugin
 */

	global $wpdb;

	$table_siigo_config = $wpdb->prefix . "bc_sgo_config";
    $sii_logs   = "DROP TABLE IF EXISTS {$table_siigo_config} ";
    $wpdb->query($sii_logs);

    $table_siigo_keys = $wpdb->prefix . "bc_sgo_keys";
    $sii_logs   = "DROP TABLE IF EXISTS {$table_siigo_keys} ";
    $wpdb->query($sii_logs);

    $table_siigo_products = $wpdb->prefix . "bc_sgo_products";
    $sii_logs   = "DROP TABLE IF EXISTS {$table_siigo_products} ";
    $wpdb->query($sii_logs);

    $table_siigo_customers = $wpdb->prefix . "bc_sgo_customers";
    $sii_logs   = "DROP TABLE IF EXISTS {$table_siigo_customers} ";
    $wpdb->query($sii_logs);