<?php

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );



// verifico si está activo el plugin de billconnector services
if(!(is_plugin_active(SERVICE_A_BILLCONNECTOR))){
    global $wpdb;
    $data = array(
        'active' => 0,
    );
    $result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'ALEGRA']);
    // como no está activo, desactivo alegra
    deactivate_plugins(SERVICE_A_ALEGRA_SLUG);    

}

/**
 * Filtro para saber si hay 'conflicto de convivencia'
 * @author Matías
 */
    if ( is_plugin_active(SERVICE_A_SII_SLUG) ) {
        global $wpdb;
		$data = array(
			'active' => 0,
		);
		$result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'SII']);
        deactivate_plugins(SERVICE_A_SII_SLUG);    
    }   

    if ( is_plugin_active(SERVICE_A_SIIGO_SLUG) ) {
        global $wpdb;
		$data = array(
			'active' => 0,
		);
		$result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'SIIGO']);
        deactivate_plugins(SERVICE_A_SIIGO_SLUG);    
    }   

    if ( is_plugin_active(SERVICE_A_SUNAT_SLUG) ) {
        global $wpdb;
		$data = array(
			'active' => 0,
		);
		$result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'SUNAT']);
        deactivate_plugins(SERVICE_A_SUNAT_SLUG);    
    }   


