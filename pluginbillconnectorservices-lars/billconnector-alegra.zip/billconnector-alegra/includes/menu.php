<?php 

function wab_add_option_admin_menu(){
    $page_title = 'BillConnector Alegra';
    $menu_title = 'Integración Alegra';
    $capability = 'manage_options';
    $slug = 'billconnector_alegra';
    $callback = 'wab_admin_menu_content';
    add_submenu_page( 
        'billconnector',
        $page_title,
        $menu_title,
        'manage_options',
        $slug,
        $callback 
    );
}
add_action('admin_menu', 'wab_add_option_admin_menu', 11);

function wab_admin_menu_content(){
    require_once( plugin_dir_path(__FILE__) . '../admin/views/index.php' );
}



