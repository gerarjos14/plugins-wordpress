<h5 class="text-sp title-modal" style="font-weight: bold;">
    Configuración
</h5>
<hr class="divideer">
<form method="POST" class="form-keys">
    <div class="modal-body">
    
        
        <input id="alegra_token" name="token" class="regular-text form-control inputs-admin-config" type="hidden" value="<?php if ($general_settings) {echo $general_settings->token;} ?>">
                
        <table class="form-table p-2">
            <tr>
                <th class="row-title">
                    <label class="text-bc" for="alegra_order_status">Pedido en estado:</label>
                </th>
                <td>
                    <select name="order_status" id="alegra_order_status" class="text-bc regular-text form-control">
                        <option value="0" <?php if ($result) { if (!$result->order_status) { echo 'selected';}} ?>>Procesando</option>
                        <option value="1" <?php if ($result) { if ($result->order_status) { echo 'selected'; }} ?>>Completado</option>
                    </select>
                </td>
            </tr>
        </table>
    </div>

    <div class="modal-footer">
        <button id="sendForm" type="button" class="btn btn-bc text-bc">Guardar cambios</button>
        <button type="button" class="btn btn-secondary-bc text-bc"  data-dismiss="modal">Cancelar</button>
    </div>
</form>
