<?php
/**
 * Archivo del plugin 
 * Este archivo es leído por WordPress para generar la información del plugin
 * en el área de administración del complemento. Este archivo también incluye 
 * todas las dependencias utilizadas por el complemento, registra las funciones 
 * de activación y desactivación y define una función que inicia el complemento.
 *
 * @link                https://billconnector.com
 * @since               1.0.0
 * @package             Billconnector
 * @author     			BillConnector <contacto@lars.net.co>
 *
 * @wordpress-plugin
 * 
 * Plugin Name: BillConnector Alegra
 * Plugin URI:  https://billconnector.com
 * Description: Servicio de BillConnector para integrar alegra a woocommerce
 * Version:     2.0.0
 * Author:      BillConnector
 * Author URI:  https://billconnector.com
 * License:     GPL2
 * License URI: https://www.gnu.org/licences/gpl-2.0.html
 * Text Domain: BillConnector Alegra
 */

if( ! defined('ABSPATH') ){
    die("Oh, there\'s nothing to see here.");
}

define( 'ALEGRA_BILL_REALPATH_BASENAME_PLUGIN', dirname( plugin_basename( __FILE__ ) ) . '/' );
define( 'ALEGRA_BILL_PLUGIN_DIR_PATH', plugin_dir_path( __FILE__ ) );
define( 'ALEGRA_BILL_PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );
define( 'ALEGRA_BILL_FILE', __FILE__);


/** ----------  TABLAS ------------*/
define('BC_TABLE_ALEGRA_CONFIG', "{$wpdb->prefix}bc_a_config");

/**--------------- ESPACIO PARA SLUGS DE SERVICIOS -----------------*/

define('SERVICE_A_ALEGRA_SLUG', 'billconnector-alegra/billconnector-alegra.php');
define('SERVICE_A_BILLCONNECTOR', 'billconnectorservices/billconnector.php');
define('SERVICE_A_SIIGO_SLUG', 'billconnector-siigo/siigo-connector.php');
define('SERVICE_A_SUNAT_SLUG', 'billconnector-sunat/billconnector-sunat.php');
define('SERVICE_A_SII_SLUG', 'billconnector-sii/billconnector.php');

/**--------------- ESPACIO PARA SLUGS DE SERVICIOS -----------------*/

/**
 * The code that runs during plugin activation.
 */


    register_activation_hook(__FILE__, 'active_alegra_service');
        
     

    function active_alegra_service(){
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        global $wpdb;

        $table_name = $wpdb->prefix . "bc_a_config";
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            token varchar(255) NOT NULL,
            order_status BOOLEAN NOT NULL DEFAULT 0,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        dbDelta( $sql );

        if ( !is_plugin_active(SERVICE_A_BILLCONNECTOR) ) {
            deactivate_plugins(SERVICE_A_ALEGRA_SLUG);    
        } 

        // active plugin final
        $data = array(
            'active' => 1,
        );
        $result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'ALEGRA']);



    }


    /**
     * The code that runs during plugin deactivation.
     */
    register_deactivation_hook(__FILE__, function(){
        global $wpdb;
        //
        $data = array(
            'active' => 0,
        );
        $result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'ALEGRA']);

    });

    /**
     * Añade el menu
     */
    if(is_admin()){
        require_once plugin_dir_path(__FILE__) . '/includes/menu.php';
    }

    /**
     * Enqueue scripts and styles
     */
    add_action('admin_enqueue_scripts', function($hook){
        if($hook === 'toplevel_page_woocommerce-alegra-billing'){
            wp_enqueue_script('bootstrapJs', plugins_url('assets/bootstrap/js/bootstrap.min.js', __FILE__), ['jquery']);
            wp_enqueue_style('bootstrapCSS', plugins_url('assets/bootstrap/css/bootstrap.min.css', __FILE__));
            wp_enqueue_script('alegraBillingJs', plugins_url('assets/js/woocommerce-alegra-billing.js', __FILE__), ['jquery']);

            wp_localize_script(
                'alegraBillingJs',
                'ajaxData',
                [
                    'ajax_url'  => admin_url('admin-ajax.php'),
                    'nonce'     => wp_create_nonce('data_security')
                ]
            );
        }
    });

    /**
     * Insert or Update Keys
     */
    if(is_admin()){
        require_once plugin_dir_path(__FILE__) . '/includes/handle-db.php';
    }

    /**
     * Hook(Action) after payment complete
     */
    require_once plugin_dir_path(__FILE__) . '/includes/action-payment-complete.php';
    require_once plugin_dir_path(__FILE__) . '/includes/check-services-active.php';
