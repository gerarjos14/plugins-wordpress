=== Akismet Anti-Spam ===
Contributors: leo, dani, mati, lud, wen
Tags: billconnector, connector, billing, siigo, alegra, chile, sii
Requires at least: 4.6
Tested up to: 5.4
Stable tag: 1.0
License: GPLv2 or later

Billconnector allows you to connect your ecommerce with siigo, alegra or the sii in chile to generate electronic invoices.

== Description ==

Billconnector connects your ecommerce to generate invoices in siigo or alegra or the sii


Major features in Billconnector include:

* Every purchase generates an electronic invoice inside the software that you choose.
* You can see your invoice inside the Billconnector menu with the order number if you are using the sii or you can go to app.billconnector.com and see the pdf there.

== Installation ==

Upload the Billconnector plugin to your blog, activate it, and then enter your Billconnector.com API key.

1, 2, 3: You're done!

== Changelog ==

= 1.0 =
*Release Date - 01 September 2021*

- The first deploy with all the major features!
