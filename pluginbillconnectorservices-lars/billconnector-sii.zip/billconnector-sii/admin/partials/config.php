<h5 class="text-sp title-modal" style="font-weight: bold;">
    Configuración
</h5>
<hr class="divideer">

<form method="POST" class="sii-form-keys">
    <div class="modal-body">
        <table class="form-table p-2">
            <tr>
                <input id="sii-token" name="token" class="regular-text form-control inputs-admin-config" type="hidden" value="<?php if ($general_settings) {echo $general_settings->token;} ?>">
                <th class="row-title">
                        <label class="text-bc" for="access_key">Realizar factura cuando la orden este en el estado de:</label>
                </th>      
                <td>
                    <select name="order_status" id="sii-order_status" class="regular-text form-control">
                        <option value="0" <?php if($result){ if(!$result->order_status){ echo 'selected'; }} ?> >Procesando</option>
                        <option value="1" <?php if($result){ if($result->order_status){ echo 'selected'; }} ?> >Completado</option>
                    </select>
                </td>             
            </tr>            
        </table>

        
        <input type="hidden" id="sii-nonce" name="nonce" value="<?php echo wp_create_nonce( 'bc_seg' );?>">

        
    </div>
    <div class="modal-footer">
        <button id="send-key-sii" type="button" class="btn btn-bc btn-submit-config text-bc">Guardar cambios</button>
    </div>
</form>

<script src="<?php echo SII_BC_PLUGIN_DIR_URL . 'admin/js/bc-admin.js' ?>"></script>
