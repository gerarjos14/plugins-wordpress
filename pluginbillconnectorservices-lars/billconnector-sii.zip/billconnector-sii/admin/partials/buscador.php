<h5 class="text-sp title-modal" style="font-weight: bold;">
    <b>Buscar documentos por nro de pedido</b>
</h5>
<hr class="divideer">

<div class="search-content d-flex flex-wrap">
    <input type="number" name="nro-order" id="nro-order" class="mr-2">
    <button type="button" class="btn btn-bc" id="search-order">Buscar</button>
</div>
    <br>
<div class="search-result"  id="sii-search-result">

</div>
