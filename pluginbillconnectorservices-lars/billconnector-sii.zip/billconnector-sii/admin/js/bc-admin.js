(function( $ ) {
	'use strict';
	var $precargador = $('.precargador');
    
    /**
     * Modal con el Formulario para guardar claves
     */
    $('#changeKeysSII').click(function (e) {
        e.preventDefault();
        $('#modalChangeKey').modal('show');
    });

    /**
     * Evento click para guardar
     * el registro en la base de datos
     * utilizando AJAX
     */
    $('#send-key-sii').on( 'click', function(e){
        e.preventDefault();
        $precargador.css( 'display', 'flex' );
        
        
        var token        = $('#sii-token').val();
        var order_status = $('#sii-order_status').val();
        var sii_nonce    = $('#sii-nonce').val();


        var bc_sii = {
            nonce: $('#service-nonce').val(),
            url: '/wp-admin/admin-ajax.php'
        };

        // Envío de AJAX
        $.ajax({
            url         : bc_sii.url,
            type        : 'POST',
            dataType    : 'json',
            data : {
                action          : 'bc_sii_config',
                nonce           : sii_nonce,
                token         	: token,
                order_status    : order_status,
            }, success  : function( data ) {

                console.log(data);
                swal({
                    title: "Ok!",
                    text: 'Se ha modificado la configuración de SII con éxito',
                    icon: 'success',
                }).then(
                    function(){
                        window.location.reload();
                    }
                );


            }, error: function( d,x,v ) {
                swal({
                    title: "Error",
                    text: 'Ha ocurrido un error al momento de guardar la configuración',
                    icon: 'error',
                }).then(
                    function(){
                        window.location.reload();
                    }
                );

                console.log(d);
                console.log(x);
                console.log(v);
            }
        });

    });


    $('#search-order').click(function (e) {
        const btn = $(this);
        btn.prop('disabled', true);

        var nro_order = $('#nro-order').val();
        nro_order=parseInt(nro_order);
        if (isNaN(nro_order)==true){
            btn.prop('disabled', false);
            return false;
        }
        $.ajax({
            url      : bc.url,
            type     : 'POST',
            datatype : 'json',
            data: {
                action    : 'bc_search_order',
                nonce     : bc.seguridad,
                nro_order : nro_order,
            },
            success: function (data) {
                btn.prop('disabled', false);
                let response = JSON.parse(data);
                $('#search-result').html(response.html);
            },
            error: function (d, x, v) {
                btn.prop('disabled', false);
                console.log(d);
                console.log(x);
                console.log(v);
            }
        });

    });
})( jQuery );