<?php

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );


// verifico si está activo el plugin de billconnector services
if(!(is_plugin_active(SERVICE_SII_BILLCONNECTOR))){
    global $wpdb;
		$data = array(
			'active' => 0,
		);
    $result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'SII']);
    // como no está activo, desactivo alegra
    deactivate_plugins(SERVICE_SII_SII_SLUG);    

}

if ( is_plugin_active(SERVICE_SII_ALEGRA_SLUG) ) {
    global $wpdb;
		$data = array(
			'active' => 0,
		);
		$result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'ALEGRA']);
    deactivate_plugins(SERVICE_SII_ALEGRA_SLUG);    
}   

if ( is_plugin_active(SERVICE_SII_SIIGO_SLUG) ) {
    global $wpdb;
		$data = array(
			'active' => 0,
		);
		$result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'SIIGO']);
    deactivate_plugins(SERVICE_SII_SIIGO_SLUG);    
}   

if ( is_plugin_active(SERVICE_SII_SUNAT_SLUG) ) {
    global $wpdb;
		$data = array(
			'active' => 0,
		);
		$result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'SUNAT']);
    deactivate_plugins(SERVICE_SII_SUNAT_SLUG);    
}   

