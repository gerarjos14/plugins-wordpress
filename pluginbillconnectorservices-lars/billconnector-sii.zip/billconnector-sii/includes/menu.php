<?php 

function sii_add_option_admin_menu(){
    $page_title = 'BillConnector SII';
    $menu_title = 'Integración SII';
    $capability = 'manage_options';
    $slug = 'billconnector_sii';
    $callback = 'SII_admin_menu_content';
    add_submenu_page( 
        'billconnector',
        $page_title,
        $menu_title,
        'manage_options',
        $slug,
        $callback 
    );
}
add_action('admin_menu', 'sii_add_option_admin_menu', 11);

function SII_admin_menu_content(){
    require_once( plugin_dir_path(__FILE__) . '../admin/partials/bc-admin-display.php' );
}

