<?php
/**
 * Archivo del plugin 
 * Este archivo es leído por WordPress para generar la información del plugin
 * en el área de administración del complemento. Este archivo también incluye 
 * todas las dependencias utilizadas por el complemento, registra las funciones 
 * de activación y desactivación y define una función que inicia el complemento.
 *
 * @link                https://billconnector.com
 * @since               1.0.0
 * @package             Billconnector
 * @author     			BillConnector <contacto@lars.net.co>
 *
 * @wordpress-plugin
 * Plugin Name:         Billconnector SII
 * Plugin URI:          https://billconnector.com
 * Description:         Integración con SII de Chile
 * Version:             2.0.0
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}
global $wpdb;
define( 'SII_BC_REALPATH_BASENAME_PLUGIN', dirname( plugin_basename( __FILE__ ) ) . '/' );
define( 'SII_BC_PLUGIN_DIR_PATH', plugin_dir_path( __FILE__ ) );
define( 'SII_BC_PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );
define( 'SII_BC_FILE', __FILE__);


// define( 'SII_BILL_URL', 'http://localhost:8000/');
// define( 'SII_BILL_URL_API', 'http://localhost:8000/api/');
// define( 'SII_BILL_URL', 'https://app.billconnector.com/');
// define( 'SII_BILL_URL_API', 'https://app.billconnector.com/api/');
define( 'SII_BILL_URL', 'http://billconnector.test/');
define( 'SII_BILL_URL_API', 'http://billconnector.test/api/');

define('BC_TABLE_SII_CONFIG', "{$wpdb->prefix}bc_sii_config");
define('BC_TABLE_SII_ORDERS', "{$wpdb->prefix}bc_sii_orders");
define('BC_TABLE_SII_LOGS', "{$wpdb->prefix}bc_log_orders");
define( 'BC_TABLE_USERS', "{$wpdb->prefix}users" );
define( 'BC_TABLE_USERS_META', "{$wpdb->prefix}usermeta" );


define('SERVICE_SII_ALEGRA_SLUG', 'billconnector-alegra/billconnector-alegra.php');
define('SERVICE_SII_BILLCONNECTOR', 'billconnectorservices/billconnector.php');
define('SERVICE_SII_SIIGO_SLUG', 'billconnector-siigo/siigo-connector.php');
define('SERVICE_SII_SUNAT_SLUG', 'billconnector-sunat/billconnector-sunat.php');
define('SERVICE_SII_SII_SLUG', 'billconnector-sii/billconnector.php');

/**
 * Código que se ejecuta en la activación del plugin
 */
function activate_billconnector_sii() {
    require_once SII_BC_PLUGIN_DIR_PATH . 'includes/class-bc-activator.php';
	SII_BC_Activator::activate();

	if ( !is_plugin_active(SERVICE_SII_BILLCONNECTOR) ) {
		deactivate_plugins(SERVICE_SII_ALEGRA_SLUG);    
	} 

	global $wpdb;
	
	$data = array(
		'active' => 1,
	);
	$result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'SII']);
}

/**
 * Código que se ejecuta en la desactivación del plugin
 */
function deactivate_billconnector_sii() {
    require_once SII_BC_PLUGIN_DIR_PATH . 'includes/class-bc-deactivator.php';
	SII_BC_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_billconnector_sii' );
register_deactivation_hook( __FILE__, function(){
		global $wpdb;
		$data = array(
			'active' => 0,
		);
		$result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'SII']);

		'deactivate_billconnector_sii';
		wp_clear_scheduled_hook( 'signal_promo_cron_hook' );
	});


require_once SII_BC_PLUGIN_DIR_PATH . 'includes/class-bc-master.php';
require_once SII_BC_PLUGIN_DIR_PATH . 'includes/class-bc-helpers.php';
require_once SII_BC_PLUGIN_DIR_PATH . '/includes/check-services-active.php';

// if( false === $is_admin ){
// 	add_filter( 'option_active_plugins', function( $plugins ){

// 		global $request_uri;

// 		$is_contact_page = strpos( $request_uri, '/contact/' );

// 		$myplugins = array(SERVICE_SII_ALEGRA_SLUG);

// 		if( false === $is_contact_page ){
// 			$plugins = array_diff( $plugins, $myplugins );
// 		}

// 		return $plugins;

// 	} );
// }



if (!function_exists('is_woocommerce_active')){
	function is_woocommerce_active(){
	    $active_plugins = (array) get_option('active_plugins', array());
	    if(is_multisite()){
		   $active_plugins = array_merge($active_plugins, get_site_option('active_sitewide_plugins', array()));
	    }
	    return in_array('woocommerce/woocommerce.php', $active_plugins) || array_key_exists('woocommerce/woocommerce.php', $active_plugins) || class_exists('WooCommerce');
	}
}

if(is_woocommerce_active()) {
    function run_sii_bc_master() {
		global $wpdb;
        $bc_master = new SII_BC_Master;
        $bc_master->run();
		$data = array(
            'active' => 1,
        );
        $result = $wpdb->update("{$wpdb->prefix}bc_services", $data, ['name' => 'SII']);

    }

    run_sii_bc_master();
}


	
	remove_action('admin_menu', 'wab_add_option_admin_menu');

	add_action('bill_connector_cron_hook_send_email', 'processs_send_email');

	