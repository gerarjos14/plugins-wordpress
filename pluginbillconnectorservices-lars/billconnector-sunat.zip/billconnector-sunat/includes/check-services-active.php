<?php

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );



// verifico si está activo el plugin de billconnector services
if(!(is_plugin_active(SERVICE_SUNAT_BILLCONNECTOR))){
    // como no está activo, desactivo alegra
    deactivate_plugins(SERVICE_SUNAT_SUNAT_SLUG);    

}

/**
 * Filtro para saber si hay 'conflicto de convivencia'
 * @author Matías
 */
function check_conflic_services(){
    if ( is_plugin_active(SERVICE_SUNAT_SII_SLUG) ) {
        deactivate_plugins(SERVICE_SUNAT_SII_SLUG);    
    }   

    if ( is_plugin_active(SERVICE_SUNAT_SIIGO_SLUG) ) {
        deactivate_plugins(SERVICE_SUNAT_SIIGO_SLUG);    
    }   

    if ( is_plugin_active(SERVICE_SUNAT_ALEGRA_SLUG) ) {
        deactivate_plugins(SERVICE_SUNAT_ALEGRA_SLUG);    
    }   
    
}
