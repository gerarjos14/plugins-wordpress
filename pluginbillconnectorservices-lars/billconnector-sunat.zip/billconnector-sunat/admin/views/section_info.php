<h5 class="text-sp title-modal" style="font-weight: bold;">
Información
</h5>
<p class="text-bc">
    Recuerde que el cliente debe completar los siguientes campos de forma obligatoria 
    para que la facturación pueda funcionar correctamente.
</p>

<table class="form-table p-2">
                    <tr>
                        <th class="row-title text-bc">
                            Nombre
                        </th>
                        <td>
                            Nombre del cliente
                        </td>
                    </tr>
                    <tr>
                        <th class="row-title text-bc">
                            Apellido
                        </th>
                        <td>
                            Apellido del cliente
                        </td>
                    </tr>
                    <tr>
                        <th class="row-title text-bc">
                            Email
                        </th>
                        <td>
                            Email del cliente
                        </td>
                    </tr>
                    <tr>
                        <th class="row-title text-bc">
                            Telefono
                        </th>
                        <td>
                            Telefono del cliente
                        </td>
                    </tr>
                    <tr>
                        <th class="row-title text-bc">
                            Dirección
                        </th>
                        <td>
                            Dirección del cliente
                        </td>
                    </tr>
                    <tr>
                        <th class="row-title text-bc">
                            Ciudad
                        </th>
                        <td>
                            Ciudad del cliente
                        </td>
                    </tr>
                    <tr>
                        <th class="row-title text-bc">
                            Codigo postal
                        </th>
                        <td>
                            Codigo postal del cliente
                        </td>
                    </tr>
                </table>
