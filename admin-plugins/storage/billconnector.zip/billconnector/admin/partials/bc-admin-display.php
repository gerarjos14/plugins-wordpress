<?php

/**
  * Proporcionar una vista de área de administración para el plugin
  *
  * Este archivo se utiliza para marcar los aspectos de administración del plugin.
  *
  * @link http://misitioweb.com
  * @since desde 1.0.0
  *
  * @package Billconnector
  * @subpackage Billconnector/admin/parcials
  */
$result =  $this->helpers->get_config_db(); 
?>
<div class="wrap">
  <a id="changeKeys" class="page-title-action" style="font-size: 15px;">Configurar</a>
  <br><br>
  <div class="welcome-panel p-2">
      <h3><b>Buscar documentos por nro de pedido</b></h3> <hr>
      <div class="card-body">            
          <div class="search-content d-flex flex-wrap">
            <input type="number" name="nro-order" id="nro-order" class="mr-2">
            <button type="button" class="button button-primary" id="search-order">Buscar</button>
          </div>
          <br>
          <div class="search-result"  id="search-result">

          </div>
      </div>               
  </div>

  <div id="modalChangeKey" class="modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document" style="max-width: 600px!important; margin-top:4rem!important;">
      <div class="modal-content" style="border-radius:0px!important">
        <div class="precargador">
          <div class="spinner-border" role="status">
            <span class="sr-only">Loading...</span>
          </div>
        </div>
        <div class="modal-header">
          <h5>Configurar</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form method="POST" class="form-keys">
          <div class="modal-body">           
            <h5 style="font-size: 1.1rem;">Api Siigo</h5>
            <table class="form-table p-2">  
                <tr>
                    <th class="row-title">
                        <label for="token">Token</label>
                    </th>
                    <td>
                        <input id="token" name="token" class="regular-text form-control" type="text" 
                        value="<?php if($result){echo $result->token;}?>">
                    </td>
                </tr> 
                   
                <tr>
                    <th class="row-title">
                        <label for="access_key">Realizar factura cuando la orden este en el estado de:</label>
                    </th>      
                    <td>
                        <select name="order_status" id="order_status" class="regular-text form-control">
                            <option value="0" <?php if($result){ if(!$result->order_status){ echo 'selected'; }} ?> >Procesando</option>
                            <option value="1" <?php if($result){ if($result->order_status){ echo 'selected'; }} ?> >Completado</option>
                        </select>
                    </td>             
                </tr>   
            </table>   
          </div>
          <div class="modal-footer">
            <button id="send-keys" type="button" class="btn btn-primary">Guardar cambios</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
          </div>
        </form>
      </div>
    </div>
  </div>

</div>
