<?php
/**
 * Archivo del plugin 
 * Este archivo es leído por WordPress para generar la información del plugin
 * en el área de administración del complemento. Este archivo también incluye 
 * todas las dependencias utilizadas por el complemento, registra las funciones 
 * de activación y desactivación y define una función que inicia el complemento.
 *
 * @link                https://billconnector.com
 * @since               1.0.0
 * @package             Billconnector
 * @author     			BillConnector <contacto@lars.net.co>
 *
 * @wordpress-plugin
 * Plugin Name:         Billconnector
 * Plugin URI:          https://billconnector.com
 * Version:             1.0.0

 */

if ( ! defined( 'WPINC' ) ) {
	die;
}
global $wpdb;
define( 'BC_REALPATH_BASENAME_PLUGIN', dirname( plugin_basename( __FILE__ ) ) . '/' );
define( 'BC_PLUGIN_DIR_PATH', plugin_dir_path( __FILE__ ) );
define( 'BC_PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );
define( 'BC_FILE', __FILE__);


// define( 'BC_URL', 'http://127.0.0.1:8000/');
// define( 'BC_URL_API', 'http://127.0.0.1:8000/api/');
define( 'BC_URL', 'https://app.billconnector.com/');
define( 'BC_URL_API', 'https://app.billconnector.com/api/');



define( 'BC_TABLE', "{$wpdb->prefix}bc_config" );
define( 'BC_TABLE_ORDERS', "{$wpdb->prefix}bc_orders" );
define( 'BC_TABLE_LOGS', "{$wpdb->prefix}bc_logs" );


/**
 * Código que se ejecuta en la activación del plugin
 */
function activate_billconnector() {
    require_once BC_PLUGIN_DIR_PATH . 'includes/class-bc-activator.php';
	BC_Activator::activate();
}

/**
 * Código que se ejecuta en la desactivación del plugin
 */
function deactivate_billconnector() {
    require_once BC_PLUGIN_DIR_PATH . 'includes/class-bc-deactivator.php';
	BC_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_billconnector' );
register_deactivation_hook( __FILE__, 'deactivate_billconnector' );

require_once BC_PLUGIN_DIR_PATH . 'includes/class-bc-master.php';

if (!function_exists('is_woocommerce_active')){
	function is_woocommerce_active(){
	    $active_plugins = (array) get_option('active_plugins', array());
	    if(is_multisite()){
		   $active_plugins = array_merge($active_plugins, get_site_option('active_sitewide_plugins', array()));
	    }
	    return in_array('woocommerce/woocommerce.php', $active_plugins) || array_key_exists('woocommerce/woocommerce.php', $active_plugins) || class_exists('WooCommerce');
	}
}

if(is_woocommerce_active()) {
    function run_bc_master() {
        $bc_master = new BC_Master;
        $bc_master->run();
    }

    run_bc_master();
}
























