<div class="row">
        <div class="col-md-12">
            <div class="card text-white bg-danger card-no-plugin">
                <div class="card-body">
                    <h5 class="text-sp card-title">Error configuración</h5>
                    <p class="text-sp">
                       <b>
                           Antes de seleccionar el alamacen debe de cargar los 
                           datos de la configuración de Woocommerce
                       </b>
                    </p>
                </div>
            </div>
        </div>
    </div>