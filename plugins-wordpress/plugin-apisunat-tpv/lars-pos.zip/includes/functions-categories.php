<?php


function check_percentage($id_categorie){
    global $wpdb;

}